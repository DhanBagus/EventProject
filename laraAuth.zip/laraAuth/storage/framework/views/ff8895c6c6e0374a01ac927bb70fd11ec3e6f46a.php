



<?php $__env->startSection('content'); ?>

<div class="container mt-3">
        <div class="row">
            <div class="col-md-12">

                <!-- Notifikasi menggunakan flash session data -->
                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="alert alert-error">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>

                <div class="card border-0 shadow rounded col-md-5">
                    <div class="card-body">
                        <h3 class="text-center">Detail Event / <?php echo e($data['event']->title); ?></h3>
                        <table>
                            
                            <tr>
                                <td>Tanggal</td>
                                <td> : </td>
                                <td><?php echo e($data['event']->date); ?></td>
                            </tr>
                            <tr>
                                <td>Jumlah Peserta</td>
                                <td> : </td>
                                <td><?php echo e($data['event']->jum_peserta); ?></td>
                            </tr>
                            <tr>
                                <td>Harga</td>
                                <td> : </td>
                                <td>Rp. <?php echo e(number_format($data['event']->harga)); ?></td>
                            </tr>
                            <tr>
                                <td>Jumlah Terdaftar</td>
                                <td> : </td>
                                <td><?php echo e($data['jum_partisipan']); ?></td>
                            </tr>
                            <tr>
                                <td>Penghasilan</td>
                                <td> : </td>
                                <td>Rp. <?php echo e(number_format($data['event']->harga*$data['jum_partisipan'])); ?></td>
                            </tr>

                        </table>
                    </div>
                </div>

                <div class="card border-0 shadow rounded mt-3">
                    <div class="card-body">
                        <h3 class="text-center mb-3">List Partisipan</h3>
                        <table class="table table-bordered mt-1">
                            <thead>
                                <tr>
                                    
                                    <th scope="col">Nama</th>
                                    <th scope="col">Kontak</th>
                                    <th scope="col">Keterangan</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data['partisipan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $par): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                   
                                    <td><?php echo e($par->nama); ?></td>
                                    <td><?php echo e($par->kontak); ?></td>
                                    <td><?php echo e($par->keterangan); ?></td>
                                    
                                    
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center text-mute" colspan="3">Data Event tidak tersedia</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraAuth\resources\views/Event/show.blade.php ENDPATH**/ ?>